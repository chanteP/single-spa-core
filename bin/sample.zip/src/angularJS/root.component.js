import angular from 'angular';
import template from './root.template.html';

angular
  .module('angularJS-app')
  .component('root', {
    template,
  })