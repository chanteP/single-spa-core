import angular from 'angular';
import 'angular-ui-router';

angular
  .module('angularJS-app', ['ui.router']);